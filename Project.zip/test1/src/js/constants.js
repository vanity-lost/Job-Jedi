/* eslint-disable no-unused-vars */
const exbrowser = "chrome";
// values: "chrome", "safari", "edge", "firefox", "opera", "yandex", "whale"
const browsernewtab = "chrome://newtab/";
const browserstore = "https://chrome.google.com";
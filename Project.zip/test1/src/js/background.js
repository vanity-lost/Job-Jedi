//================================================
/*

Browser extension starter template
The development ready template for beginner
Copyright (C) 2022 Stefan vd
www.stefanvd.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


To view a copy of this license, visit http://creativecommons.org/licenses/GPL/2.0/

*/
//================================================

// Importing the constants
// eslint-disable-next-line no-undef
importScripts("constants.js");
const fs = require('fs');
import { OpenAI } from "langchain/llms/openai";
import {
  ChatPromptTemplate,
  HumanMessagePromptTemplate,
  PromptTemplate,
  SystemMessagePromptTemplate,
} from "langchain/prompts";
import { LLMChain } from "langchain/chains";
import { ChatOpenAI } from "langchain/chat_models/openai";

const model = new OpenAI({ openAIApiKey: "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", temperature: 0 });
const template = "What is a good name for a company that makes {background}, {job}?";

async function generate_resume(background_info, job_description) {
    // We can construct an LLMChain from a PromptTemplate and an LLM.
    var prompt = new PromptTemplate({ template, inputVariables: ["background", "job"] });
    var resume_chain = new LLMChain({ llm: model, prompt });
    var result = await resume_chain.call({ background: background_info, job: job_description });
    console.log(result);

    var latex_template = fs.readFileSync('resume.tex', 'utf8');
    console.log(latex_template);

    // Generate the PDF document
    const pdftex = new PDFTeX();
    pdftex.compile(latex_code)
      .then(function(pdf) { window.open(pdf) });
}
